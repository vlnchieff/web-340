console.error("Error: This script has failed intentionally for testing purposes.");
process.exit(1); // Exit with a non-zero status code to indicate failure
